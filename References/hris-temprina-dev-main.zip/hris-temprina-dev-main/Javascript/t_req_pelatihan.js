import { useRouter, useRoute, RouterLink } from 'vue-router'
import { ref, readonly, reactive, inject, onMounted, onBeforeMount, watchEffect, onActivated, computed } from 'vue'

const router = useRouter()
const route = useRoute()
const store = inject('store')
const swal = inject('swal')

const isRead = route.params.id && route.params.id !== 'create'
const actionText = ref(route.params.id === 'create' ? 'Tambah' : (route.query.action?.toLowerCase() === 'verifikasi' ? null : route.query.action))
const isBadForm = ref(false) 
const isRequesting = ref(false)
const is_approval = route.query.is_approval ? true : false
const modulPath = route.params.modul
const currentMenu = store.currentMenu
const apiTable = ref(null)
const formErrors = ref({})
const tsId = `ts=` + (Date.parse(new Date()))
let dataLog = reactive({ items: [] })
let modalOpen = ref(false)
let isFinish = ref(false)
let isApproved = ref(false)

const isUserHC = computed(() => {
  const respoData = localStorage.getItem('respo')
  if (respoData) {
    try {
      const respo = JSON.parse(respoData)
      const respoName = (respo.name || respo.nama || '').toUpperCase()
      if (respoName.includes('HC') || respoName.includes('HUMAN CAPITAL') || respoName.includes('HRD')) {
        return true
      }
      return false
    } catch (e) { }
  }
  return store.user.data?.is_hc === true || store.user.data?.is_hc === 1
})

// ------------------------------ PERSIAPAN
const endpointApi = '/t_request_pelatihan'
onBeforeMount(() => {
  document.title = 'Pengajuan Pelatihan'
})

function onPrint(id = null) {
  const targetId = id || route.params.id
  if (!targetId || targetId === 'create') return
  window.open(`${store.server.url_backend}/web/report_req_pelatihan?id=${targetId}&export=pdf`, '_blank')
}

//  @if( $id )------------------- VALUES FORM ! PENTING JANGAN DIHAPUS
let initialValues = {}
const changedValues = []

onBeforeMount(async () => {
  document.title = is_approval ? 'Approval Pengajuan Pelatihan' : 'Form Pengajuan Pelatihan'
  // console.log('cek hc', store.user.data.is_hc)

  const respoData = localStorage.getItem('respo')
  if (respoData) {
    const respoValues = JSON.parse(respoData)
    // console.log('ini respo', respoValues)
    values.m_comp_id = respoValues.m_comp_id
    values.m_subcomp_id = respoValues.m_subcomp_id
    values.m_branch_id = respoValues.m_branch_id
    // console.log('ini comp',values.m_comp_id)
  }
})

const values = reactive({
  status: 'DRAFT',
  catatan_revisi: ''
})

onBeforeMount(async () => {
  // console.log('test')
  // onReset()
  if (isRead) {
    //  READ DATA
    try {
      let dataURL = ''
      let dataURLAprv = ''
      let resAprv = ''
      if (route.query.is_approval) {
        dataURLAprv = `${store.server.url_backend}/operation${endpointApi}/app_detail?id=${route.params.id}`;
        isRequesting.value = true
        const apiApp = await fetch(dataURLAprv, {
          headers: {
            'Content-Type': 'Application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
        })
        const resultJson = await apiApp.json()
        if (!apiApp.ok) {
          throw new Error(resultJson.message || "Failed when trying to read approval data");
        }

        // Redirect immediately to the Verifikasi endpoint using the real trx_id
        const trx_id = resultJson.data.approval.trx_id;
        const tsId = `ts=` + (Date.parse(new Date()));
        window.location.replace(`/t_req_pelatihan/${trx_id}?action=Verifikasi&${tsId}`);
        return;
      } else {
        const editedId = route.params.id
        const dataURL = `${store.server.url_backend}/operation${endpointApi}/${editedId}`
        isRequesting.value = true

        const params = { join: true, transform: true }
        const fixedParams = new URLSearchParams(params)
        const res = await fetch(dataURL + '?' + fixedParams, {
          headers: {
            'Content-Type': 'Application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
        })
        if (!res.ok) throw new Error("Failed when trying to read data")
        const resultJson = await res.json()
        initialValues = resultJson.data

        if (initialValues['status']) {
          values.status_name = initialValues['status']

          if (initialValues['status'].toUpperCase() === 'REVISED') {
            try {
              const urlLog = `${store.server.url_backend}/operation${endpointApi}/app_log?id=${editedId}`
              const resLog = await fetch(urlLog, { headers: { Authorization: `${store.user.token_type} ${store.user.token}` } })
              if (resLog.ok) {
                const resultLog = await resLog.json()
                console.log('--- DEBUG REVISED LOG FETCH ---', resultLog)
                const logsArray = Array.isArray(resultLog) ? resultLog : (resultLog.data || [])
                console.log('--- DEBUG REVISED LOG ARRAY ---', logsArray)
                if (logsArray && Array.isArray(logsArray)) {
                  // Ambil catatan REVISED terbaru
                  const revisedLog = logsArray.slice().reverse().find(log => log.action_type && log.action_type.toUpperCase() === 'REVISED')
                  console.log('--- DEBUG REVISED LOG FOUND ---', revisedLog)
                  if (revisedLog) {
                    values.catatan_revisi = revisedLog.action_note || '(Tidak ada catatan)'
                  } else {
                    values.catatan_revisi = 'Belum ada log revisi'
                  }
                }
              }
            } catch (e) {
              console.warn('Gagal memuat log revisi', e)
            }
          }
        }
        if (actionText.value?.toLowerCase() === 'copy' && initialValues.id) {
          delete initialValues.id, delete initialValues.no, delete initialValues.date, delete initialValues.status
        }

        // Menambahkan Data Ke Array

        initialValues.t_request_pelatihan_d_kary?.forEach((items) => {
          if (actionText.value?.toLowerCase() === 'copy' && items.id) {
            delete items.id, delete items.no
          }

          detailArr.value = [items, ...detailArr.value]
        })

        // initialValues.t_mou_d?.forEach((items)=>{  
        //   if(actionText.value?.toLowerCase() === 'copy' && items.id){
        //     delete items.id
        //   }                
        //   detailArrPengambilan.value = [items, ...detailArrPengambilan.value]
        // })
        // if(!initialValues.sopir_id){
        //   initialValues.flag='customer'
        // }

        // initialValues.t_mou_d.forEach((dt) => {
        //   console.log('cek 3', dt.vi.qty_2_stock)
        //   console.log(dt)
        // })
        // console.log(initialValues.t_request_pelatihan_d_kary)
        detailArr.value = await Promise.all(
          (initialValues?.t_request_pelatihan_d_kary || []).map(async (dt) => {
            // initialValues.t_request_pelatihan_d_kary.map(async (dt) => {
            let cabang_kary = ''
            let divisi_kary = ''
            let posisi_kary = ''
            const branchId = dt['m_kary.m_branch_id']
            const divisiId = dt['m_kary.m_divisi_id']
            const posisiId = dt['m_kary.m_posisi_id']

            if (branchId) {
              try {
                const resBranch = await fetch(`${store.server.url_backend}/operation/m_branch/${branchId}`, {
                  headers: {
                    Authorization: `${store.user.token_type} ${store.user.token}`
                  }
                })
                if (resBranch.ok) {
                  const branchJson = await resBranch.json()
                  cabang_kary = branchJson.data?.name || ''
                }
              } catch (err) {
                console.warn('Gagal ambil nama branch:', err)
              }
            }

            if (divisiId) {
              try {
                const resDivisi = await fetch(`${store.server.url_backend}/operation/m_divisi/${divisiId}`, {
                  headers: {
                    Authorization: `${store.user.token_type} ${store.user.token}`
                  }
                })
                if (resDivisi.ok) {
                  const divisiJson = await resDivisi.json()
                  divisi_kary = divisiJson.data?.name || ''
                }
              } catch (err) {
                console.warn('Gagal ambil nama divisi:', err)
              }
            }

            if (posisiId) {
              try {
                const resDivisi = await fetch(`${store.server.url_backend}/operation/m_posisi/${posisiId}`, {
                  headers: {
                    Authorization: `${store.user.token_type} ${store.user.token}`
                  }
                })
                if (resDivisi.ok) {
                  const posisiJson = await resDivisi.json()
                  posisi_kary = posisiJson.data?.name || ''
                }
              } catch (err) {
                console.warn('Gagal ambil nama divisi:', err)
              }
            }

            return {
              ...dt,
              nama_kary: dt['m_kary.nama_lengkap'] || dt['nama_lengkap'],
              cabang_kary,
              divisi_kary,
              posisi_kary
            }
          })
        )

        // console.log(initialValues.t_mou_d)
      }
    } catch (err) {
      isBadForm.value = true
      swal.fire({
        icon: 'error',
        text: err,
        allowOutsideClick: false,
        confirmButtonText: 'Kembali',
      }).then(() => {
        router.back()
      })
    }
    isRequesting.value = false
  }

  for (const key in initialValues) {
    values[key] = initialValues[key]
  }
})

let _id = 0
const detailArr = ref([])
const onDetailAdd = (e) => {
  e.forEach(row => {
    row.t_mou_d = row.id;
    detailArr.value.push(row)
  });
}

const removeDetail = (index) => {
  detailArr.value.splice(index, 1)
}

function onBack() {
  let isChanged = false
  for (const key in initialValues) {
    if (values[key] !== initialValues[key]) {
      isChanged = true
      break;
    }
  }

  if (!isChanged) {
    router.replace('/' + modulPath)
    return
  }

  router.replace('/' + modulPath)

}

function onReset() {
  swal.fire({
    icon: 'warning',
    text: 'Reset this form data?',
    showDenyButton: true
  }).then((res) => {
    if (res.isConfirmed) {
      for (const key in initialValues) {
        values[key] = initialValues[key]
      }
    }
  })
}


async function posted() {
  const payload = {
    id: route.params.id
  }
  try {
    const dataURL = `${store.server.url_backend}/operation${endpointApi}/posted`
    isRequesting.value = true
    const res = await fetch(dataURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      body: JSON.stringify(payload)
    })
    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.message || "Failed when trying to post data")
      } else {
        throw ("Failed when trying to post data")
      }
    }
    router.replace('/' + modulPath + '?reload=' + (Date.parse(new Date())))
  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: err
    })
  }
  isRequesting.value = false

}

async function approval() {
  if (!isUserHC.value && !values.target_id) {
    swal.fire({
      icon: 'warning',
      text: 'Pilih Target Approval (Atasan) terlebih dahulu!'
    })
    return
  }

  const confirmTitle = isUserHC.value ? 'Konfirmasi Approval HC' : 'Konfirmasi Approval'
  const confirmText = isUserHC.value ? 'Pengajuan oleh akun HC akan langsung disetujui (Approved). Lanjutkan?' : 'Kirim permintaan approval ke atasan?'

  const confirmRes = await swal.fire({
    title: confirmTitle,
    text: confirmText,
    icon: 'question',
    showCancelButton: true
  })
  if (!confirmRes.isConfirmed) return

  const payload = {
    id: parseInt(route.params.id),
    target_id: values.target_id || null
  }
  try {
    const dataURL = `${store.server.url_backend}/operation${endpointApi}/send_approval`
    isRequesting.value = true
    const res = await fetch(dataURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      body: JSON.stringify(payload)
    })
    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.message || "Failed when trying to post data")
      } else {
        throw ("Failed when trying to post data")
      }
    }
    const resultJson = await res.json()
    await swal.fire({
      icon: 'success',
      text: resultJson.message || (isUserHC.value ? 'Pengajuan oleh HC berhasil diajukan dan langsung disetujui' : 'Permintaan approval berhasil dibuat')
    })
    router.replace('/' + modulPath + '?reload=' + (Date.parse(new Date())))
  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: err
    })
  }
  isRequesting.value = false

}

async function actionProgress(type) {
  let text = '';

  if (type !== 'APPROVED') {
    const result = await swal.fire({
      title: 'Catatan ' + type,
      input: 'textarea',
      inputPlaceholder: 'Tuliskan catatan di sini...',
      showCancelButton: true
    })
    if (result.value === undefined) return; // user cancelled
    text = result.value;
  } else {
    const result = await swal.fire({
      title: 'Konfirmasi Approval',
      text: 'Apakah Anda yakin ingin menyetujui pengajuan ini?',
      icon: 'question',
      showCancelButton: true
    })
    if (!result.isConfirmed) return;
  }

  const payload = {
    id: parseInt(route.params.id),
    type: type,
    note: type === 'APPROVED' ? 'Disetujui' : text
  }
  try {
    const dataURL = `${store.server.url_backend}/operation${endpointApi}/progress`
    isRequesting.value = true
    const res = await fetch(dataURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      body: JSON.stringify(payload)
    })

    if (!res.ok) {
      const responseJson = await res.json().catch(() => ({}));
      throw (responseJson.message || responseJson.error || "Failed when trying to post data")
    }
    router.replace('/t_req_pelatihan?reload=' + (Date.parse(new Date())))
  } catch (err) {
    swal.fire({ icon: 'error', text: err })
  }
  isRequesting.value = false
}

async function onSave() {
  try {
    formErrors.value = {}
    let hasError = false
    const requiredFields = ['date_from', 'date_to', 'm_comp_id', 'm_subcomp_id', 'm_branch_id', 'm_prog_pelatihan_id', 'sarana', 'trainer_id']

    requiredFields.forEach(field => {
      if (!values[field]) {
        formErrors.value[field] = ['Bidang ini wajib di isi']
        hasError = true
      }
    })

    if (hasError) {
      isBadForm.value = true
      swal.fire({
        icon: 'error',
        text: 'Lengkapi Data Terlebih Dahulu !'
      })
      return
    }

    values.t_request_pelatihan_d_kary = detailArr.value.map(row => {
      const newRow = { ...row }
      // Jika m_kary_id sudah ada (dari load backend), pakai itu. Jika kosong (dari pilih modal), pakai row.id
      newRow.m_kary_id = row.m_kary_id ? row.m_kary_id : row.id
      // Jika m_kary_id sudah ada, berarti row.id adalah ID detail, biarkan saja. Jika tidak, set null agar dianggap record baru.
      newRow.id = row.m_kary_id ? row.id : null

      newRow['m_kary.m_branch_id'] = null
      newRow['m_kary.m_divisi_id'] = null
      newRow['m_kary.m_posisi_id'] = null
      newRow['m_branch_id'] = row.m_branch_id || null
      newRow['m_divisi_id'] = row.m_divisi_id || null
      newRow['m_posisi_id'] = row.m_posisi_id || null

      // BUANG tanggal bawaan dari m_kary agar generator tidak mencoba parse dan meledak
      delete newRow.created_at
      delete newRow.updated_at

      return newRow
    })
    // Jika status REVISED, otomatis kembalikan ke DRAFT saat disimpan ulang
    if (values.status && values.status.toUpperCase() === 'REVISED') {
      values.status = 'DRAFT';
    }

    const isCreating = ['Create', 'Copy', 'Tambah'].includes(actionText.value)

    if (isCreating) {
      values.status = 'DRAFT';
      if (!values.m_subcomp_id) values.m_subcomp_id = data.subcomp_id;
      if (!values.m_branch_id) values.m_branch_id = data.branch_id;
    }

    const dataURL = `${store.server.url_backend}/operation${endpointApi}${isCreating ? '' : ('/' + route.params.id)}`
    isRequesting.value = true
    console.log('=== PAYLOAD YANG DIKIRIM ===', JSON.stringify(values))
    const res = await fetch(dataURL, {
      method: isCreating ? 'POST' : 'PUT',
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      body: JSON.stringify(values)
    })
    console.log('=== RESPONSE STATUS ===', res.status, res.statusText)
    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.errors.length ? responseJson.errors[0] : responseJson.message || "Failed when trying to post data")
      } else {
        const errBody = await res.text()
        console.log('=== ERROR BODY ===', errBody)
        throw ("Failed when trying to post data (status: " + res.status + ")")
      }
    }
    const responseJson = await res.json().catch(() => ({}))
    console.log('=== RESPONSE BODY ===', responseJson)
    await swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Data berhasil disimpan' + (responseJson?.data?.id ? ' (ID: ' + responseJson.data.id + ')' : ''),
      timer: 2000,
      showConfirmButton: false
    })
    router.replace('/' + modulPath + '?reload=' + (Date.parse(new Date())))
  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: typeof err === 'string' ? err : (err?.message || JSON.stringify(err))
    })
  }
  isRequesting.value = false
}

//  @else----------------------- LANDING
const activeBtn = ref()
function filterShowData(statusLabel = null, noBtn = null) {
  const statusMap = {
    1: 'DRAFT',
    2: 'POSTED',
    3: 'IN APPROVAL',
    4: 'REVISED',
    6: 'APPROVED',
    7: 'REJECTED',
  }

  if (noBtn !== null) {
    if (activeBtn.value === noBtn) {
      activeBtn.value = null
      statusLabel = null
    } else {
      activeBtn.value = noBtn
    }
  } else {
    statusLabel = statusMap[activeBtn.value] || null
  }
  const filters = []

  if (statusLabel) {
    filters.push(`this.status='${statusLabel?.toUpperCase()}'`)
  }

  filterWhere.value = filters.length ? filters.join(' AND ') : null
  setTimeout(() => {
    if (apiTable.value) apiTable.value.reload()
  }, 50)
}

const filterWhere = ref(null)

const data = reactive({
  can_read: false,
  can_create: false,
  can_update: false,
  can_delete: false,
  respo_id: null,
  subcomp_id: null,
  branch_id: null
})

const isAccessReady = ref(false)

function openModal(id) {
  dataLog.items = []
  modalOpen.value = true
  loadLog(id)
  console.log('kontol', modalOpen.value)
}

function closeModal(i) {
  dataLog.items = []
  modalOpen.value = false
}

async function loadLog(id) {
  const url = `${store.server.url_backend}/operation${endpointApi}/app_log?id=${id}`
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'Application/json',
      Authorization: `${store.user.token_type} ${store.user.token}`
    },
  })
  if (!res.ok) throw new Error("Failed when trying to read data")
  const result = await res.json()
  dataLog.items = result
  console.log('cek', result)
}

onBeforeMount(async () => {
  if (localStorage.getItem('respo')) {
    const v = JSON.parse(localStorage.getItem('respo'))
    data.respo_id = v.id
    data.subcomp_id = v.m_subcomp_id
    data.branch_id = v.m_branch_id
  }

  if (!data.respo_id) return

  const params = new URLSearchParams({
    path: route.path,
    respo_id: data.respo_id
  })

  const res = await fetch(
    `${store.server.url_backend}/operation/m_general/access?${params}`,
    { headers: { Authorization: `${store.user.token_type} ${store.user.token}` } }
  )

  const r = await res.json()

  data.can_read = r.can_read
  data.can_create = r.can_create
  data.can_update = r.can_update
  data.can_delete = r.can_delete

  isAccessReady.value = true
})

const landing = computed(() => {
  if (!isAccessReady.value) return null

  return {
    actions: [
      {
        icon: 'trash',
        class: 'bg-red-600 text-light-100',
        title: "Hapus",
        show: (row) => row.status?.toUpperCase() !== 'POSTED' && data.can_delete,
        click(row) {
          swal.fire({
            icon: 'warning',
            text: 'Hapus Data Terpilih?',
            confirmButtonText: 'Yes',
            showDenyButton: true,
          }).then(async (result) => {
            if (result.isConfirmed) {
              try {
                const dataURL = `${store.server.url_backend}/operation${endpointApi}/${row.id}`
                isRequesting.value = true
                const res = await fetch(dataURL, {
                  method: 'DELETE',
                  headers: {
                    'Content-Type': 'Application/json',
                    Authorization: `${store.user.token_type} ${store.user.token}`
                  }
                })
                if (!res.ok) throw ("Failed when trying to remove data")
                apiTable.value.reload()
                // const resultJson = await res.json()
              } catch (err) {
                isBadForm.value = true
                swal.fire({
                  icon: 'error',
                  text: err
                })
              }
              isRequesting.value = false
            }
          })
        }
      },
      {
        icon: 'eye',
        title: "Read",
        class: 'bg-green-600 text-light-100',
        show: (row) => data.can_read,
        click(row) {
          router.push(`${route.path}/${row.id}?` + tsId)
        }
      },
      {
        icon: 'edit',
        title: "Edit",
        class: 'bg-blue-600 text-light-100',
        show: (row) => ['DRAFT', 'REVISED'].includes(row.status?.toUpperCase()) && data.can_update,
        click(row) {
          router.push(`${route.path}/${row.id}?action=Edit&` + tsId)
        }
      },
      {
        icon: 'copy',
        title: "Copy",
        class: 'bg-gray-600 text-light-100',
        show: (row) => !['POSTED', 'REJECTED'].includes(row.status?.toUpperCase()) && data.can_create,
        click(row) {
          router.push(`${route.path}/${row.id}?action=Copy&` + tsId)
        }
      },
      {
        icon: 'paper-plane',
        title: "Posted Data",
        class: 'bg-rose-700 rounded-lg text-white',
        show: (row) => row.status?.toUpperCase() === 'DRAFT' && data.can_update,
        async click(row) {
          const result = await swal.fire({
            icon: 'warning',
            text: 'Post Data?',
            iconColor: '#1469AE',
            confirmButtonColor: '#1469AE',
            showDenyButton: true
          })
          if (!result.isConfirmed) return
          try {
            isRequesting.value = true
            const url = `${store.server.url_backend}/operation${endpointApi}/posted`
            const res = await fetch(url, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `${store.user.token_type} ${store.user.token}`
              },
              body: JSON.stringify({ id: row.id })
            })
            const json = await res.json()
            if (!res.ok) throw (json?.message || json?.data?.errorText || 'Failed when trying to post data')
            if (json.status && json.status.toUpperCase() !== 'SUCCESS') {
              swal.fire({ icon: 'info', text: json.message || 'Status tidak success' })
              apiTable.value.reload()
              return
            }
            swal.fire({ icon: 'success', text: json.message || 'Data berhasil diposting' })
            apiTable.value.reload()
          } catch (err) {
            isBadForm.value = true
            swal.fire({ icon: 'error', iconColor: '#1469AE', confirmButtonColor: '#1469AE', text: err })
          } finally {
            isRequesting.value = false
          }
        }
      },
      {
        icon: 'location-arrow',
        title: "Send Approval",
        class: 'bg-rose-700 rounded-lg text-white',
        show: (row) => row.status?.toUpperCase() === 'POSTED' && data.can_update,
        click(row) {
          router.push(`${route.path}/${row.id}?action=Verifikasi&` + tsId)
        }
      },
      {
        icon: 'check-square',
        title: "Review Data",
        class: 'bg-blue-600 rounded-lg text-white',
        show: (row) => row.status?.toUpperCase() === 'IN APPROVAL' && data.can_update,
        click(row) {
          router.push(`${route.path}/${row.id}?action=Verifikasi&` + tsId)
        }
      },
      {
        icon: 'history',
        title: "Log Approval",
        class: 'bg-purple-600 rounded-lg text-white',
        show: (row) => ['APPROVED', 'IN APPROVAL', 'HALF APPROVED', 'REVISED', 'REJECTED'].includes(row['status']) && data.can_read,
        click(row) {
          openModal(row.id)
        }
      },
      {
        icon: 'print',
        title: "Cetak Surat Pengajuan",
        class: 'bg-emerald-600 rounded-lg text-white',
        show: (row) => data.can_read,
        click(row) {
          const targetId = row?.id 
            || (apiTable.value?.selectedRows || [])[0]?.id 
            || apiTable.value?.selectedRow?.id 
            || apiTable.value?.selected?.id
            || apiTable.value?.dataSelected?.id
          if (targetId && targetId !== 'create') {
            const url = `${store.server.url_backend}/web/report_req_pelatihan?id=${targetId}&export=pdf`
            window.open(url, '_blank')
          } else {
            swal.fire({
              icon: 'info',
              text: 'Silakan klik salah satu baris pengajuan pada tabel terlebih dahulu, lalu klik tombol Cetak.'
            })
          }
        }
      }

    ],

    api: {
      url: data.can_read
        ? `${store.server.url_backend}/operation${endpointApi}`
        : null,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      params: {
        join: true,
        transform: true,
        scopes: 'respo',
        where: filterWhere.value
      },
      onsuccess(r) {
        r.page = r.current_page
        r.hasNext = r.has_next
        return r
      }
    },

    columns: [{
      headerName: 'No',
      valueGetter: (params) => params.node.rowIndex + 1,
      width: 60,
      sortable: true,
      resizable: true,
      filter: true,
      cellClass: ['justify-center', 'bg-gray-50', 'border-r', '!border-gray-200']
    },
    {
      headerName: 'Kode',
      field: 'kode',
      wrapText: true,
      filter: true,
      sortable: true,
      flex: 1,
      filter: 'ColFilter',
      resizable: true,
      cellClass: ['border-r', '!border-gray-200', 'justify-start']
    },
    {
      field: 'trainer.nama_trainer',
      headerName: 'Nama Trainer',
      filter: true,
      sortable: true,
      flex: 2,
      filter: 'ColFilter',
      resizable: true,
      cellClass: ['border-r', '!border-gray-200', 'justify-start']
    },
    {
      field: 'm_prog_pelatihan.tema_pelatihan',
      headerName: 'Nama Pelatihan',
      filter: true,
      sortable: true,
      flex: 2,
      filter: 'ColFilter',
      resizable: true,
      cellClass: ['border-r', '!border-gray-200', 'justify-start']
    },
    {
      headerName: 'Tanggal Awal',
      field: 'date_from',
      filter: true,
      sortable: true,
      flex: 1,
      filter: 'ColFilter',
      resizable: true,
      cellClass: ['border-r', '!border-gray-200', 'justify-start']
    },
    {
      headerName: 'Tanggal Akhir',
      field: 'date_to',
      filter: true,
      sortable: true,
      flex: 1,
      filter: 'ColFilter',
      resizable: true,
      cellClass: ['border-r', '!border-gray-200', 'justify-start']
    },
    {
      headerName: 'Status',
      field: 'status',
      filter: true,
      sortable: true,
      filter: 'ColFilter',
      resizable: true,
      flex: 1,
      cellClass: ['border-r', '!border-gray-200', 'justify-center'],
      cellRenderer: ({ value }) => {
        let color = 'gray'
        if (value == 'POSTED' || value == 'APPROVED')
          color = 'green'
        else if (value == 'IN APPROVAL')
          color = 'blue'
        else if (value == 'REVISED')
          color = 'yellow'
        else if (value == 'REJECTED')
          color = 'red'
        return `<span class="text-${color}-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">${value}</span>`
      }
    }
    ]
  }
})

onActivated(() => {
  //  reload table api landing
  if (apiTable.value) {
    if (route.query.reload) {
      apiTable.value.reload()
    }
  }
})

//  @endif -------------------------------------------------END
watchEffect(() => store.commit('set', ['isRequesting', isRequesting.value]))
