<?php

/**
 * placeholder model: m_kary_det_bhs
 * bagian: Alter
 * tempel source code dari generator lama di file ini.
 */
