<?php

namespace App\Models\CustomModels;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Excel as ExcelType;
Carbon::setLocale("id");


class m_kary_det_kontrak extends \App\Models\BasicModels\m_kary_det_kontrak
{    
    private $helper;
    public function __construct()
    {
        parent::__construct();
        $this->helper = getCore("Helper");
    }
    
    public $fileColumns    = [ 'contract' ];

    //public $createAdditionalData = ["creator_id"=>"auth:id"];
    //public $updateAdditionalData = ["last_editor_id"=>"auth:id"];

    public function createBefore( $model, $arrayData, $metaData, $id=null )
    {
        $nomor = @$arrayData['nomor'] ?? $this->helper->generateNomor("KODE KONTRAK");
        $newArrayData  = array_merge( $arrayData,[
                "nomor" => $nomor,
        ]);

        return [
            "model"  => $model,
            "data"   => $newArrayData,
        ];
    }

    public function createAfter($model, $arrayData, $metaData, $id = null)
    {
        $exists = \App\Models\BasicModels\t_extend_kontrak::where('nomor', $model->nomor)->exists();

        if (!$exists) {
            $prevContract = \App\Models\BasicModels\m_kary_det_kontrak::where('m_karyawan_id', $model->m_karyawan_id)
                ->where('id', '!=', $model->id)
                ->orderBy('id', 'desc')
                ->first();

            $ext = new \App\Models\BasicModels\t_extend_kontrak();
            $ext->nomor = $model->nomor;
            $ext->m_karyawan_id = $model->m_karyawan_id;
            $ext->m_divisi_id = $model->m_divisi_id;
            $ext->m_dir_id = $model->m_dir_id;
            $ext->tipe_karyawan_id = $model->tipe_karyawan_id;
            $ext->tgl_awal = $model->tgl_awal;
            $ext->tgl_akhir = $model->tgl_akhir;
            $ext->duration = $model->duration;
            $ext->contract_signed = $model->contract;
            $ext->status = 'COMPLETED';
            $ext->m_kary_det_kontrak_id = $prevContract ? $prevContract->id : null;
            $ext->catatan = 'Diinput langsung via Data Karyawan';
            $ext->save();
        }
    }

    public function t_extend_kontrak() :\HasMany
    {
        return $this->HasMany('App\Models\BasicModels\t_extend_kontrak', 'm_kary_det_kontrak_id', 'id');
    }

    public function scopeEndKontrak($model)
    {
        $periode_awal = app()->request->start_month;   // format: YYYY-MM
        $periode_akhir = app()->request->end_month;    // format: YYYY-MM

        $id_tetap = m_general::where('group', 'TIPE KARYAWAN')
            ->where('key', 'T')
            ->first()?->id ?? 0;

        if (!$periode_akhir) {
            $periode_akhir = Carbon::now()->format('Y-m');
        }

        try {
            $endDate = Carbon::createFromFormat('Y-m', $periode_akhir)->endOfMonth();
        } catch (\Exception $e) {
            $endDate = Carbon::now()->endOfMonth();
        }

        $query = $model
            ->select(
                'm_kary.id',
                'm_kary.nama_lengkap as m_kary.nama_lengkap',
                'm_divisi.nama as jabatan',
                'm_dir.nama as m_dir.nama',
                'tipe_karyawan.value as tipe_karyawan',
                'tipe_karyawan.value as tipe_karyawan.value',
                'm_kary_det_kontrak.*'
            )
            ->join('m_kary', 'm_kary_det_kontrak.m_karyawan_id', 'm_kary.id')
            ->where('m_kary.is_active', true)
            ->whereNull('m_kary.tgl_berhenti')
            ->where('m_kary_det_kontrak.status', true)
            ->whereDoesntHave('t_extend_kontrak', function($q) {
                $q->whereIn('status', ['COMPLETED', 'APPROVED']);
            })
            ->whereNotIn('m_kary_det_kontrak.tipe_karyawan_id', (array) $id_tetap);

        // Jika periode_awal dikirim spesifik, gunakan range. Jika default, ambil akumulasi sampai periode_akhir
        if ($periode_awal) {
            try {
                $startDate = Carbon::createFromFormat('Y-m', $periode_awal)->startOfMonth();
                $query->whereBetween('m_kary_det_kontrak.tgl_akhir', [$startDate, $endDate]);
            } catch (\Exception $e) {
                $query->where('m_kary_det_kontrak.tgl_akhir', '<=', $endDate);
            }
        } else {
            $query->where('m_kary_det_kontrak.tgl_akhir', '<=', $endDate);
        }

        return $query->orderBy('m_kary_det_kontrak.tgl_akhir', 'ASC');
    }

    public function public_exportEndKontrak()
    {
        try {
            $fileName =
                "data_expired_kontrak_" .
                Carbon::now()->format("Ymd_His") .
                ".xlsx";

            $periode_awal = app()->request->start_month;   // format: YYYY-MM
            $periode_akhir = app()->request->end_month;    // format: YYYY-MM

            $id_tetap = m_general::where('group', 'TIPE KARYAWAN')
                ->where('key', 'T')
                ->first()?->id ?? 0;

            if (!$periode_akhir) {
                $periode_akhir = Carbon::now()->format('Y-m');
            }

            try {
                $endDate = Carbon::createFromFormat('Y-m', $periode_akhir)->endOfMonth();
            } catch (\Exception $e) {
                $endDate = Carbon::now()->endOfMonth();
            }

            $query = m_kary_det_kontrak::join('m_kary', 'm_kary_det_kontrak.m_karyawan_id', 'm_kary.id')
                ->where('m_kary.is_active', true)
                ->whereNull('m_kary.tgl_berhenti')
                ->where('m_kary_det_kontrak.status', true)
                ->whereDoesntHave('t_extend_kontrak', function($q) {
                    $q->whereIn('status', ['COMPLETED', 'APPROVED']);
                })
                ->whereNotIn('m_kary_det_kontrak.tipe_karyawan_id', (array) $id_tetap);

            if ($periode_awal) {
                try {
                    $startDate = Carbon::createFromFormat('Y-m', $periode_awal)->startOfMonth();
                    $query->whereBetween('m_kary_det_kontrak.tgl_akhir', [$startDate, $endDate]);
                } catch (\Exception $e) {
                    $query->where('m_kary_det_kontrak.tgl_akhir', '<=', $endDate);
                }
            } else {
                $query->where('m_kary_det_kontrak.tgl_akhir', '<=', $endDate);
            }

            $data = $query->orderBy('m_kary_det_kontrak.tgl_akhir', 'ASC')
                ->get()
                ->map(function ($extend) {
                    $isPast = $extend->tgl_akhir ? Carbon::parse($extend->tgl_akhir)->isPast() : false;
                    return [
                        "NAMA_KARYAWAN" =>
                            $extend->m_karyawan?->nama_lengkap ?? "",
                        "DIVISI" => $extend->m_karyawan?->m_divisi?->nama ?? "",
                        "UNIT" => $extend->m_dir?->nama ?? "",
                        "TIPE_KARYAWAN" => $extend->tipe_karyawan?->value ?? "",
                        "TANGGAL_MULAI" => $extend->tgl_awal
                            ? Carbon::parse($extend->tgl_awal)->format("d-m-Y")
                            : "",
                        "TANGGAL_SELESAI" => $extend->tgl_akhir
                            ? Carbon::parse($extend->tgl_akhir)->format("d-m-Y")
                            : "",
                        "STATUS_KONTRAK" => $isPast ? 'Sudah Berakhir (Expired)' : 'Akan Berakhir',
                        "STATUS_DATA" => ($extend->status ?? false) ? 'Aktif' : 'Nonaktif',
                        "DIBUAT_PADA" => $extend->created_at
                            ? $extend->created_at->format("Y-m-d H:i:s")
                            : "",
                    ];
                });

            // Buat export dinamis tanpa file terpisah
            $export = new class ($data) implements FromCollection, WithHeadings
            {
                protected $data;
                public function __construct($data)
                {
                    $this->data = $data;
                }
                public function collection()
                {
                    return $this->data;
                }
                public function headings(): array
                {
                    return [
                        "NAMA KARYAWAN",
                        "DIVISI",
                        "UNIT",
                        "TIPE KARYAWAN",
                        "TANGGAL MULAI",
                        "TANGGAL SELESAI",
                        "STATUS KONTRAK",
                        "STATUS DATA",
                        "DIBUAT PADA",
                    ];
                }
            };

            return Excel::download($export, $fileName, ExcelType::XLSX);
        } catch (\Exception $e) {
            return response()->json(
                [
                    "error" =>
                        "Terjadi kesalahan saat export: " . $e->getMessage(),
                ],
                500
            );
        }
    }

    public function custom_countend()
    {
        $endDate = Carbon::now()->addDays(30)->format('Y-m-d');
        $date = Carbon::now()->translatedFormat('F Y');

        $id_tetap = m_general::where('group', 'TIPE KARYAWAN')
            ->where('key', 'T')
            ->first()?->id ?? 0;

        $count = m_kary_det_kontrak::where('tgl_akhir', '<=', $endDate)
            ->where('status', true)
            ->whereDoesntHave('t_extend_kontrak', function($q) {
                $q->whereIn('status', ['COMPLETED', 'APPROVED']);
            })
            ->whereNotIn('m_kary_det_kontrak.tipe_karyawan_id', (array) $id_tetap)
            ->count();

        return response()->json([
            "periode" => $date,
            "count_end" => $count,
        ]);
    }

    public function custom_notifEndKontrak()
    {
        $endDate = Carbon::now()->addDays(30)->format('Y-m-d');

        $id_tetap = m_general::where('group', 'TIPE KARYAWAN')
            ->where('key', 'T')
            ->first()?->id ?? 0;

        $data = m_kary_det_kontrak::join('m_kary', 'm_kary_det_kontrak.m_karyawan_id', 'm_kary.id')
            ->leftJoin('m_divisi', 'm_kary_det_kontrak.m_divisi_id', 'm_divisi.id')
            ->leftJoin('m_dir', 'm_kary_det_kontrak.m_dir_id', 'm_dir.id')
            ->select(
                'm_kary.nama_lengkap',
                'm_divisi.nama as jabatan',
                'm_dir.nama as unit',
                'm_kary_det_kontrak.tgl_awal',
                'm_kary_det_kontrak.tgl_akhir'
            )
            ->where('m_kary.is_active', true)
            ->whereNull('m_kary.tgl_berhenti')
            ->where('m_kary_det_kontrak.tgl_akhir', '<=', $endDate)
            ->where('m_kary_det_kontrak.status', true)
            ->whereDoesntHave('t_extend_kontrak', function($q) {
                $q->whereIn('status', ['COMPLETED', 'APPROVED']);
            })
            ->whereNotIn('m_kary_det_kontrak.tipe_karyawan_id', (array) $id_tetap)
            ->orderBy('m_kary_det_kontrak.tgl_akhir', 'ASC')
            ->get()
            ->map(function ($item) {
                $item->is_expired = Carbon::parse($item->tgl_akhir)->isPast();
                $item->status_label = $item->is_expired ? 'Sudah Berakhir' : 'Akan Berakhir';
                return $item;
            });

        return response()->json([
            "data" => $data,
        ]);
    }

}