@verbatim
<div class="flex flex-col border shadow-sm px-6 py-6 <md:w-full w-full bg-white">
   <div class="flex items-center justify-between mb-2 pb-4">
    <div class="w-[100%]">
      <div class="flex items-center justify-between">
      <FieldX  
        class="w-70 mb-2 mt-2"
        :bind="{ readonly: false }"
        :value="values.search" 
        @input="v=>values.search=v"
        @keyup.enter="search()"
        label=""
        placeholder="Cari"
        :check="false" />
      <div class="flex justify-end">
        <button
          class="py-1.5 px-2 border-gray-300 border-2 rounded-[5px] text-gray-400"
          title="Segarkan"
          @click="loadTable()"
          >
          <Icon fa="arrow-rotate-right">
        </button>
        <FieldSelect
          class="w-20 ml-2 !mt-0"
          :bind="{ disabled: false, clearable: false }"
          :value="100" 
          :check="false"
          @input="(v)=>{
            values.paginate=v
            paginate()
          }"
          :options="[50,100,200,500]"
          fa-icon="table" :check="true" />
        </div>
      </div>
      <div class="flex items-center justify-between">
        <div class="w-[100%] h-[440px] overflow-y-scroll">
          <!-- Pengingat Jadwal Kerja Hari Ini -->
          <div v-if="dataJadwal" class="rounded-none border border-l-0 border-r-0 border-t-0 border-neutral-200 !bg-blue-50 dark:border-neutral-600 dark:bg-neutral-800 mb-4">
            <h2 class="mb-0" id="flush-headingJadwal">
              <button
                @click="isJadwalOpen = !isJadwalOpen"
                class="group relative flex w-full items-center rounded-none border-0 !bg-gradient-to-r from-blue-600 to-blue-500 px-5 py-2 text-left text-base font-medium text-white transition [overflow-anchor:none] hover:z-[2] focus:z-[3] focus:outline-none"
                type="button">
                <span class="flex items-center gap-2">
                  <Icon fa="calendar-check" />
                  Pengingat Jadwal Kerja Hari Ini
                </span>
                <span class="-mr-1 ml-auto h-5 w-5 shrink-0 fill-white transition-transform duration-200 ease-in-out">
                  <Icon :fa="isJadwalOpen ? 'arrow-down-wide-short' : 'times'" />
                </span>
              </button>
            </h2>
            <div class="!visible border-0 p-4 bg-white" :class="isJadwalOpen ? '' : 'hidden'">
              <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-3.5 rounded-lg border border-blue-100 bg-blue-50/50">
                <div class="flex-1">
                  <div class="flex items-center gap-2 mb-1.5">
                    <span class="text-xs font-bold uppercase tracking-wider bg-blue-600 text-white px-2.5 py-0.5 rounded">
                      {{ dataJadwal.nama_jadwal }}
                    </span>
                    <span v-if="dataJadwal.is_libur" class="text-xs font-semibold bg-red-100 text-red-700 px-2.5 py-0.5 rounded">
                      Libur / Tidak Aktif
                    </span>
                    <span v-else class="text-xs font-semibold bg-green-100 text-green-700 px-2.5 py-0.5 rounded">
                      Hari Kerja
                    </span>
                  </div>
                  <p class="text-sm text-gray-700 font-medium leading-relaxed">{{ dataJadwal.pesan_pengingat }}</p>
                </div>
                <div v-if="!dataJadwal.is_libur && dataJadwal.waktu_mulai" class="flex items-center gap-3 text-xs font-semibold shrink-0">
                  <div class="bg-white px-3 py-1.5 rounded-lg border border-gray-200 text-center shadow-xs">
                    <span class="text-gray-400 block text-[10px] font-bold">MASUK</span>
                    <span class="text-blue-700 text-sm font-bold">{{ dataJadwal.waktu_mulai }} WIB</span>
                  </div>
                  <div class="bg-white px-3 py-1.5 rounded-lg border border-gray-200 text-center shadow-xs">
                    <span class="text-gray-400 block text-[10px] font-bold">PULANG</span>
                    <span class="text-red-600 text-sm font-bold">{{ dataJadwal.waktu_akhir }} WIB</span>
                  </div>
                  <RouterLink to="/presensi_absen_online" class="bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-lg font-medium text-xs transition shadow-sm hover:shadow">
                    Ke Absen Online &rarr;
                  </RouterLink>
                </div>
              </div>
            </div>
          </div>

          <div v-if="dataKontrak.length > 0" class="rounded-none border border-l-0 border-r-0 border-t-0 border-neutral-200 !bg-yellow-300 dark:border-neutral-600 dark:bg-neutral-800 mb-4">
            <h2 class="mb-0" id="flush-headingKontrak">
              <button
                @click="isKontrakOpen = !isKontrakOpen"
                class="group relative flex w-full items-center rounded-none border-0 !bg-gradient-to-r from-red-500 to-red-400 px-5 py-2 text-left text-base font-medium text-white transition [overflow-anchor:none] hover:z-[2] focus:z-[3] focus:outline-none"
                type="button">
                Pemberitahuan Kontrak Karyawan Berakhir (H-30)
                <span class="-mr-1 ml-auto h-5 w-5 shrink-0 fill-white transition-transform duration-200 ease-in-out">
                  <Icon :fa="isKontrakOpen ? 'arrow-down-wide-short' : 'times'" />
                </span>
              </button>
            </h2>
            <div class="!visible border-0" :class="isKontrakOpen ? '' : 'hidden'">
              <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                  <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                      <th scope="col" class="px-6 py-3">Nama Karyawan</th>
                      <th scope="col" class="px-6 py-3">Unit</th>
                      <th scope="col" class="px-6 py-3">Jabatan</th>
                      <th scope="col" class="px-6 py-3">Tgl Mulai</th>
                      <th scope="col" class="px-6 py-3">Tgl Akhir Kontrak</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(k, idx) in dataKontrak" :key="idx" class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50">
                      <td class="px-6 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">{{ k.nama_lengkap }}</td>
                      <td class="px-6 py-2">{{ k.unit ?? '-' }}</td>
                      <td class="px-6 py-2">{{ k.jabatan ?? '-' }}</td>
                      <td class="px-6 py-2">{{ k.tgl_awal }}</td>
                      <td class="px-6 py-2 text-red-500 font-bold">{{ k.tgl_akhir }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div >
            <tbody v-if="!dataLanding.items.length">
              <tr 
                class="w-[100%] bg-white border-b dark:bg-gray-800 dark:border-gray-700" 
              >
                <th scope="row" class="w-[100%] px-6 py-2 font-medium text-blue-700 whitespace-nowrap dark:text-white">
                    Data approval tidak ditemukan
                </th>
              </tr>
            <tbody>
          </div>
          <div
            v-else
            v-for="(item,i) in dataLanding.items" :key="i"
            class="rounded-none border border-l-0 border-r-0 border-t-0 border-neutral-200 !bg-yellow-300 dark:border-neutral-600 dark:bg-neutral-800">
            <h2 class="mb-0" id="flush-headingOne hidden">
              <button
                @click="openClose(i)"
                  class="group relative flex w-full items-center rounded-none border-0 !bg-gradient-to-r from-dark-300 to-dark-100 px-5 py-1  text-left text-base font-medium  text-white transition [overflow-anchor:none] hover:z-[2] focus:z-[3] focus:outline-none dark:bg-neutral-800 dark:text-white [&:not([data-te-collapse-collapsed])]:bg-white [&:not([data-te-collapse-collapsed])]:text-primary [&:not([data-te-collapse-collapsed])]:[box-shadow:inset_0_-1px_0_rgba(229,231,235)] dark:[&:not([data-te-collapse-collapsed])]:bg-neutral-800 dark:[&:not([data-te-collapse-collapsed])]:text-primary-400 dark:[&:not([data-te-collapse-collapsed])]:[box-shadow:inset_0_-1px_0_rgba(75,85,99)]"
                type="button">
                {{ item.name }}
                <span
                  class="-mr-1 ml-auto h-5 w-5 shrink-0 rotate-[-180deg] fill-[#336dec] transition-transform duration-200 ease-in-out group-[[data-te-collapse-collapsed]]:mr-0 group-[[data-te-collapse-collapsed]]:rotate-0 group-[[data-te-collapse-collapsed]]:fill-[#212529] motion-reduce:transition-none dark:fill-blue-300 dark:group-[[data-te-collapse-collapsed]]:fill-white">
                  <Icon :fa="!item.active ? 'arrow-down-wide-short' : 'times'">
                </span>
              </button>
            </h2>
            <div
              class="!visible border-0"
              :class="item.active ? '' : 'hidden'">
              <div class="">
                <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                  <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Nomor Approval
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Nomor Transaksi
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Nama Karyawan
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Pemohon
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Unit
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Tgl Transaksi
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Tgl Pengajuan Approval
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Status
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                      <tr 
                        v-for="d, idx in item.data" :key="idx" 
                        class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 cursor-pointer" 
                        title="klik untuk membuka detail approval"
                        @click="detail(i,idx)"
                      >
                        <th scope="row" class="px-6 py-2 font-medium text-blue-700 whitespace-nowrap dark:text-white">
                            {{ d.nomor }}
                        </th>
                        <th scope="row" class="px-6 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            {{ d.trx_nomor }}
                        </th>
                        <td class="px-6 py-2 font-medium text-gray-900 dark:text-white">
                            {{ d.nama_karyawan ?? '-' }}
                        </td>
                        <td class="px-6 py-2">
                            {{ d.creator }}
                        </td>
                        <td class="px-6 py-2">
                            {{ d.unit ?? '-' }}
                        </td>
                        <td class="px-6 py-2">
                            {{ d.trx_date }}
                        </td>
                        <td class="px-6 py-2">
                            {{ d.created_at }}
                        </td>
                        <td class="px-6 py-2">
                            {{ d.status }}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <!-- <TableApi class="w-[100%] rounded-b" ref='apiTable' :api="landing.api" :columns="landing.columns"
                  :actions="landing.actions">
                  <template #header>
                  </template>
                </TableApi> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endverbatim